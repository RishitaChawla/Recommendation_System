RECOVERED FINAL OUTPUTS — IMPORTANT PROVENANCE

This folder is a recovery package assembled from previously uploaded project artifacts and the exact numeric results you pasted from your latest successful run. It is NOT a fresh execution of the scripts.

Direct copies from previously uploaded files:
- customer_segment_summary.csv (newer 334/1050/4078/12 grouping)
- customer_segment_summary_with_names.csv (earlier assistant-added descriptive names)
- customer_segments.png (previously uploaded newer segmentation figure; verify against your final clustering run)
- matrix_report.json and cleaning_log.csv (from uploaded processed.zip)

RECONSTRUCTED FROM USER-PASTED LATEST RUN OUTPUT (not original output file bytes):
- pca_vs_svd_comparison.csv (numbers copied from terminal table; limited to displayed precision)
- run_summary.json (numbers copied from your pasted JSON)
- cluster_activity_summary.csv (numbers copied from your pasted CSV)
- hit_rate_vs_k.png, fit_time_vs_k.png, reconstruction_error_vs_k.png (NEW charts plotted from reconstructed CSV; not original exported PNGs)

The final PowerPoint previously supplied was built using some earlier chart PNGs; therefore its chart images may NOT match the newer numeric results in the memo. Use the regenerated charts in this folder to update the slides.

NOT RECOVERED AS A VERIFIED FINAL-RUN FILE:
- customer_segment_assignments_anonymous.csv (older uploads exist but correspond to a different cluster configuration; do not treat them as latest).
- product_similarities_internal.csv (older file exists, but not included because it is internal and may not match final run).

For full reproducibility, rerun build_matrix.py and run_analysis.py from your own dataset and environment; do not represent these reconstructed files as a new code execution.
